GAIN FOCUS PWA · v4.0.7

This folder is ready to deploy as a Progressive Web App.

DEPLOY
1. Upload the contents of this folder to any static HTTPS host.
2. Open the resulting HTTPS address in Safari on iPhone.
3. Tap Share → Add to Home Screen → Add.
4. Launch Gain Focus from the Home Screen. It opens in standalone app mode.

OFFLINE
The main Gain Focus app shell is cached after the first successful visit. Most app features then continue working offline. Nutrition-label OCR still needs internet when it loads its external OCR library.

IMPORTANT
A PWA cannot be installed from a file:// HTML file. Service workers require HTTPS (or localhost during development).
